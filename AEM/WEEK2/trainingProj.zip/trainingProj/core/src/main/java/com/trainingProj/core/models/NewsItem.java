package com.trainingProj.core.models;

import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class NewsItem {

    @ValueMapValue
    private String title;

    @ValueMapValue
    private String newsDetail;

    @ValueMapValue
    private Calendar publishedDate;

    @ValueMapValue
    private String source;

    public String getTitle() {
        return title;
    }

    public String getNewsDetail() {
        return newsDetail;
    }

    public String getFormattedPublishedDate() {
        if (publishedDate != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");
            return sdf.format(publishedDate.getTime());
        }
        return "N/A";
    }

    public String getSource() {
        return source;
    }
}
