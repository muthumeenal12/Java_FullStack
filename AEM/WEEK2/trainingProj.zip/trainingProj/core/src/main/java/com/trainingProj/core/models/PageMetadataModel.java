package com.trainingProj.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

@Model(adaptables = Resource.class)
public class PageMetadataModel {

    @ValueMapValue
    private String ogTitle;

    @ValueMapValue
    private String ogDescription;

    @ValueMapValue
    private String ogImage;

    public String getOgTitle() {
        return ogTitle != null ? ogTitle : "Default OG Title";
    }

    public String getOgDescription() {
        return ogDescription != null ? ogDescription : "Default OG Description";
    }

    public String getOgImage() {
        return ogImage != null ? ogImage : "/content/dam/default-image.jpg";  // Default image
    }
}
