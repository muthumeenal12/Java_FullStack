package com.trainingProj.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
public class NewsModel {

    @ValueMapValue
    private String text;

    @ValueMapValue
    private String newsDetail;

    @ValueMapValue
    private String publishedDate;

    @ChildResource(name = "newsItems")
    private Resource newsItemsResource;

    public String getText() {
        return Optional.ofNullable(text).orElse("");
    }

    public String getNewsDetail() {
        return Optional.ofNullable(newsDetail).orElse("");
    }

    public String getPublishedDate() {
        return Optional.ofNullable(publishedDate).orElse("");
    }

    public List<String> getNewsItems() {
        List<String> sources = new ArrayList<>();
        if (newsItemsResource != null) {
            for (Resource item : newsItemsResource.getChildren()) {
                String source = item.getValueMap().get("source", String.class);
                if (source != null) {
                    sources.add(source);
                }
            }
        }
        return sources;
    }
}
