package com.trainingProj.workflow;

import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.exec.WorkflowProcess;
import com.adobe.granite.workflow.metadata.MetaDataMap;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(service = WorkflowProcess.class, property = {"process.label=Print Page Title"})
public class PrintPageTitleWorkflowProcess implements WorkflowProcess {

    private static final Logger LOG = LoggerFactory.getLogger(PrintPageTitleWorkflowProcess.class);

    @Override
    public void execute(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metaData) {
        // Get the page path from workflow payload
        String pagePath = workItem.getWorkflowData().getPayload().toString();

        // Get Resource Resolver from WorkflowSession
        ResourceResolver resourceResolver = workflowSession.adaptTo(ResourceResolver.class);

        if (resourceResolver != null) {
            Resource pageResource = resourceResolver.getResource(pagePath);
            if (pageResource != null) {
                String pageTitle = pageResource.getValueMap().get("jcr:title", "Title Not Found");
                LOG.info("Workflow Process Executed: Page Title is {}", pageTitle);

            } else {
                LOG.warn("Page resource not found: {}", pagePath);
            }
        } else {
            LOG.error("Resource Resolver is null");
        }
    }
}