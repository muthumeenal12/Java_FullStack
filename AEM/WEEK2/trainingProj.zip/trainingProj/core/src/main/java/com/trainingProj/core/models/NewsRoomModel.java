package com.trainingProj.core.models;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ChildResource;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Model(adaptables = Resource.class)
public class NewsRoomModel {

    @ValueMapValue
    private String pageTitle;

    @ValueMapValue
    private String pageDescription;

    @ChildResource(name = "newsArticles")
    private List<Resource> newsArticles;

    public String getPageTitle() {
        return Optional.ofNullable(pageTitle).orElse("News Room");
    }

    public String getPageDescription() {
        return Optional.ofNullable(pageDescription).orElse("Latest news and updates.");
    }

    public List<Article> getNewsArticles() {
        return newsArticles.stream().map(Article::new).collect(Collectors.toList());
    }

    public static class Article {
        private final String title;
        private final String description;
        private final String image;
        private final String publishedDate;
        private final String source;
        private final String link;

        public Article(Resource resource) {
            this.title = resource.getValueMap().get("title", String.class);
            this.description = resource.getValueMap().get("description", String.class);
            this.image = resource.getValueMap().get("image", String.class);
            this.publishedDate = resource.getValueMap().get("publishedDate", String.class);
            this.source = resource.getValueMap().get("source", String.class);
            this.link = resource.getValueMap().get("link", String.class);
        }

        public String getTitle() { return title; }
        public String getDescription() { return description; }
        public String getImage() { return image; }
        public String getPublishedDate() { return publishedDate; }
        public String getSource() { return source; }
        public String getLink() { return link; }
    }
}
