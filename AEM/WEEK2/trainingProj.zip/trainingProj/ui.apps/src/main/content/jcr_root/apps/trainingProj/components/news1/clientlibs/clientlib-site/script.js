document.addEventListener("DOMContentLoaded", function () {
    console.log("News1 component loaded!");
});
